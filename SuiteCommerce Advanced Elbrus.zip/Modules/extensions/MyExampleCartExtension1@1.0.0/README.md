A simple Backend CartComponent example which cancels the execution of the addLine method if the cart already has ten items, also duplicates the quantity of each item added to the cart. 

#Installation

In distro.json:

 * make sure this module is included in the "modules" array

 * Include the following in the ssp-libraries dependencies array: 

    "MyExampleCartExtension1"